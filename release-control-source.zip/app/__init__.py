"""Release Control application package."""
