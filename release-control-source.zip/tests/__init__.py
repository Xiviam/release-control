"""Release Control test suite."""
